package DP_Practice10.task2;

import java.util.HashMap;
import java.util.Map;

public interface StockProvider{
    double getMarketPrice(String ticker);
    String getStatus(String ticker);


}


