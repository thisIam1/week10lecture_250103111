package DP_Practice10.task1;

import java.util.Base64;

public class HeaderFooterDecorator extends ExporterDecorator {
    private final String timestamp;
    public HeaderFooterDecorator(Exporter wrappedExporter, String timestamp) {
        super(wrappedExporter);
        this.timestamp = timestamp;
    }
    public void export(String destination, String data) {
        String result = "=== METADATA HEADER: " + timestamp + " ===\n" + data + "\n" + "=== INTEGRITY CHECK: SHA-256 OK | END RECORD ===";
        super.export(destination, result);
    }
}



