package DP_Practice10.task1;

public interface ReportFormatter {
    String format(String title, String[] headers, String[][] rows);
}

