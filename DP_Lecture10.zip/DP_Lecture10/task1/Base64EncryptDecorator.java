package DP_Practice10.task1;

import java.util.Base64;

public class Base64EncryptDecorator extends ExporterDecorator{
    public Base64EncryptDecorator(Exporter wrappedExporter){
        super(wrappedExporter);
    }
    public void export(String destination, String data) {
        String encoded = Base64.getEncoder().encodeToString(data.getBytes());
        super.export(destination, "[BASE64_CIPHERTEXT:" + encoded + "]");
    }
}

