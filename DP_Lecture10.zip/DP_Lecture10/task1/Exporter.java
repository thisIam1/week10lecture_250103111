package DP_Practice10.task1;

public interface Exporter{
    void export(String destination, String data);
}

